# To enter the game
* copy the url to website: http://127.0.0.1:3000/pacman.html

# Reference
* webgl demo: https://webglfundamentals.org/

# logic of ghost
* for movement of ghost, in one second, it will have a random direction from up, down, left and right. If it can move then it move. 
* for balance, the ghosts will only move on bean, so it will increase the difficulty because this game is easy for our human. 

# undo
* have not put special item into the game